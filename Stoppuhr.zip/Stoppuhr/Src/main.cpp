//*******************************************************************
#include <stdio.h>
#include "EmbSysLib.h"
#include "ReportHandler.h"
#include "config.h"

//*******************************************************************
// RGB565 Farben
//*******************************************************************
#define COLOR_BLACK  0x0000
#define COLOR_WHITE  0xFFFF
#define COLOR_GREEN  0x07E0
#define COLOR_RED    0xF800

//*******************************************************************
class App : public Timer::Task
{
  public:
    enum State { CLEAR, RUNNING, STOPPED };

    App(Timer *timer)
    {
      timer->add(this);
    }

    void update() override
    {
      if(state == RUNNING)
      {
        subCnt++;
        if(subCnt >= 10)   // 10 � 100 �s = 1 ms
        {
          subCnt = 0;
          msCnt++;
        }
      }
    }

    void clear()
    {
      msCnt  = 0;
      subCnt = 0;
      state  = CLEAR;
    }

    void start()
    {
      state = RUNNING;
    }

    void stop()
    {
      state = STOPPED;
    }

    float getTime() const
    {
      return msCnt * 0.001f;
    }

    uint32_t getMs() const
    {
      return msCnt;
    }

    State getState() const
    {
      return state;
    }

  private:
    uint32_t msCnt  = 0;
    uint8_t  subCnt = 0;
    State    state  = CLEAR;
};

//*******************************************************************
// Balkenparameter
//*******************************************************************
#define BAR_X      40
#define BAR_Y      140
#define BAR_WIDTH  300
#define BAR_HEIGHT 20

//*******************************************************************
int main(void)
{
  lcd.clear();
  lcd.printf(0, 0, "Stoppuhr");

  App app(&timer);

  bool b1_old = false;
  bool b2_old = false;
  bool b3_old = false;

  while(1)
  {
    // --------------------------------------------------------------
// --------------------------------------------------------------
// Buttons (Flankenerkennung)
// --------------------------------------------------------------
bool b1 = Btn1.get();
bool b2 = Btn2.get();
bool b3 = Btn3.get();

if(b1 && !b1_old)
{
  app.clear();        // CLEAR
}

if(b2 && !b2_old)
{
  app.stop();        // STOP
}

if(b3 && !b3_old)
{
  app.start();         // RUN
}

b1_old = b1;
b2_old = b2;
b3_old = b3;

// --------------------------------------------------------------
// Textanzeige
// --------------------------------------------------------------
lcd.printf(2, 0, "Time: %7.3f s", app.getTime());

const char *stateStr = "";
switch(app.getState())
{
  case App::CLEAR:   stateStr = "CLEARED "; break;
  case App::RUNNING: stateStr = "RUNNING "; break;
  case App::STOPPED: stateStr = "STOPPED "; break;
}
lcd.printf(3, 0, "State: %s", stateStr);

// --------------------------------------------------------------
// Balkendiagramm
// --------------------------------------------------------------
uint32_t ms = app.getMs();
uint32_t msInSec = ms % 1000;
uint32_t barLen = (msInSec * BAR_WIDTH) / 1000;

// Hintergrund
lcd.drawRectangle(
  BAR_X, BAR_Y,
  BAR_WIDTH, BAR_HEIGHT,
  COLOR_BLACK
);

// Balken
lcd.drawRectangle(
  BAR_X, BAR_Y,
  barLen, BAR_HEIGHT,
  2,
  COLOR_GREEN
);

// --------------------------------------------------------------
// LEDs
// --------------------------------------------------------------
LD1.set(app.getState() == App::STOPPED);
LD2.set(app.getState() == App::RUNNING);


    lcd.refresh();
  }
}
