Directory     Content
---------     -------
Bitmap        Test bitmaps
Color         Selected and predefined colors
Font          Pixel font für text output on DisplayGraphic hardware
USB           Data structure for USB exampels, making Host and Device compatible
